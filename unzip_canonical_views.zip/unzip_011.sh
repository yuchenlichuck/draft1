#!/bin/bash
#SBATCH -A k1546
#SBATCH -J unzipping_011
#SBATCH -o ./unzipping_011.out
#SBATCH -e ./unzipping_011.err
#SBATCH -N 1
#SBATCH --partition=workq
#SBATCH --mail-user=habib.slim@kaust.edu.sa
#SBATCH --mail-type=ALL
#SBATCH -t 23:59:00
#SBATCH --mem=64G

unzip -n /scratch/project/k1546/backup/c100/canonical_v1_batch_v1_12.zip -d /lustre/scratch/project/k1546/models/canonical_views/
unzip -n /scratch/project/k1546/backup/c100/canonical_v1_batch_v1_13.zip -d /lustre/scratch/project/k1546/models/canonical_views/
unzip -n /scratch/project/k1546/backup/c100/canonical_v1_batch_v1_14.zip -d /lustre/scratch/project/k1546/models/canonical_views/

    
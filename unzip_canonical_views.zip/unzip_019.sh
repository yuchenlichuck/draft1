#!/bin/bash
#SBATCH -A k1546
#SBATCH -J unzipping_019
#SBATCH -o ./unzipping_019.out
#SBATCH -e ./unzipping_019.err
#SBATCH -N 1
#SBATCH --partition=workq
#SBATCH --mail-user=habib.slim@kaust.edu.sa
#SBATCH --mail-type=ALL
#SBATCH -t 23:59:00
#SBATCH --mem=64G

unzip -n /scratch/project/k1546/backup/c100/canonical_v1_batch_v1_34.zip -d /lustre/scratch/project/k1546/models/canonical_views/
unzip -n /scratch/project/k1546/backup/c100/canonical_v1_batch_v1_35.zip -d /lustre/scratch/project/k1546/models/canonical_views/
unzip -n /scratch/project/k1546/backup/c100/canonical_v1_batch_v1_36.zip -d /lustre/scratch/project/k1546/models/canonical_views/

    
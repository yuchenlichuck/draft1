#!/bin/bash
#SBATCH -A k1546
#SBATCH -J unzipping_022
#SBATCH -o ./unzipping_022.out
#SBATCH -e ./unzipping_022.err
#SBATCH -N 1
#SBATCH --partition=workq
#SBATCH --mail-user=habib.slim@kaust.edu.sa
#SBATCH --mail-type=ALL
#SBATCH -t 23:59:00
#SBATCH --mem=64G

unzip -n /scratch/project/k1546/backup/c100/canonical_v1_batch_v1_42.zip -d /lustre/scratch/project/k1546/models/canonical_views/
unzip -n /scratch/project/k1546/backup/c100/canonical_v1_batch_v1_4.zip -d /lustre/scratch/project/k1546/models/canonical_views/
unzip -n /scratch/project/k1546/backup/c100/canonical_v1_batch_v1_5.zip -d /lustre/scratch/project/k1546/models/canonical_views/

    